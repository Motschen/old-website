# Indium
Adaptation of Indigo (Reference implementation of the Fabric Rendering API) for use with Sodium. Requires Sodium [1.16.x/next branch compiled from source](https://github.com/jellysquid3/sodium-fabric), or you can use [my fork](https://github.com/comp500/sodium-fabric) with a couple temporary fixes for common mods (GeckoLib, LBG, BetterEnd).

Based heavily upon [Indigo](https://github.com/FabricMC/fabric/tree/1.16/fabric-renderer-indigo) (licensed Apache 2.0)
